# Race Split Assistant

Race Split Assistant est une WebApp/PWA mobile-first pour préparer une stratégie de course, découper une course en checkpoints, puis suivre le plan pendant l’effort avec un chrono manuel.

L’application fonctionne sans GPS, sans API externe, sans librairie externe et sans framework. Les données restent sur le téléphone ou l’ordinateur dans `localStorage`.

## Fonctionnement général

1. Créez une course avec une distance et un objectif chrono.
2. Ajoutez des checkpoints avec distance cumulée et temps cible cumulé.
3. Consultez le résumé stratégique.
4. Lancez le mode live.
5. Appuyez sur `Point passé` à chaque checkpoint réel.
6. Consultez le bilan à la fin.

Si un checkpoint de départ est à `0 km` et `00:00:00`, il est validé automatiquement au lancement. Le premier point manuel devient donc le premier vrai checkpoint après le départ.

## Lancer en local

Vous pouvez ouvrir `index.html` directement pour tester l’interface.

Pour tester la PWA et le service worker, utilisez un serveur local depuis le dossier du projet :

```bash
python -m http.server 8080
```

Puis ouvrez `http://localhost:8080`.

## Installer comme PWA sur Android

1. Ouvrez l’application dans Chrome depuis une adresse HTTPS ou `localhost`.
2. Ouvrez le menu de Chrome.
3. Choisissez `Installer l’application` ou `Ajouter à l’écran d’accueil`.
4. Lancez ensuite Race Split Assistant depuis l’écran d’accueil.

## Installer comme PWA sur iPhone

1. Ouvrez l’application dans Safari depuis une adresse HTTPS ou un serveur local accessible.
2. Touchez le bouton de partage.
3. Choisissez `Sur l’écran d’accueil`.
4. Lancez ensuite l’application depuis l’icône créée.

## Créer une course

Depuis l’accueil, utilisez `Créer une course`.

Champs obligatoires :

- nom de la course ;
- distance totale en km ;
- objectif chrono au format `HH:MM:SS` ou `MM:SS`.

Vous pouvez aussi renseigner le type de course et des notes personnelles.

## Créer des splits

Dans l’écran `Splits`, ajoutez vos checkpoints.

Chaque checkpoint contient :

- nom ;
- distance cumulée ;
- temps cible cumulé ;
- type de zone ;
- stratégie ;
- conseil personnel ;
- temps ravito max si nécessaire.

Les checkpoints sont automatiquement triés par distance. Les distances et les temps cibles doivent rester strictement croissants. L’application calcule la distance du split, le temps du split, l’allure du split, l’allure moyenne globale et le temps total prévu aux ravitos.

## Utiliser le mode live

Depuis le résumé, touchez `Lancer la course`.

Le mode live affiche :

- nom de la course ;
- chrono très visible ;
- statut d’avance ou de retard ;
- checkpoint à valider ;
- distance et temps cible ;
- conseil du segment en cours ;
- gros bouton `Point passé` ;
- dernier passage enregistré.

Le chrono utilise `Date.now()`. Il ne dépend pas d’un simple compteur `setInterval`, ce qui permet de rester fiable si le téléphone est verrouillé, si l’app passe en arrière-plan ou si l’affichage est ralenti.

## Pause et reprise

Quand vous touchez `Pause`, l’application sauvegarde l’heure de début de pause. Quand vous touchez `Reprendre`, la durée de pause est retirée du chrono.

Si l’application est fermée pendant une pause, elle reste en pause au retour et le chrono ne continue pas pendant cette période.

## Reprise après fermeture

Une course active est sauvegardée automatiquement avec :

- course active ;
- timestamp réel du départ ;
- durée de pause cumulée ;
- état `running`, `paused` ou `finished` ;
- checkpoint à valider ;
- historique des passages ;
- heure de début de pause si la course est en pause.

Au redémarrage, Race Split Assistant affiche un écran `Course en cours détectée` avec un bouton pour reprendre et un bouton pour abandonner. Abandonner supprime seulement la session active, pas les courses enregistrées.

## Exporter et importer

Depuis l’accueil :

- `Exporter JSON` télécharge toutes les courses ;
- `Importer JSON` ajoute les courses d’un fichier exporté.

L’import valide la structure de base, conserve les courses existantes et refuse les fichiers invalides avec un message clair.

## Fonctionnement hors ligne

Le service worker met en cache les fichiers principaux :

- `index.html`
- `style.css`
- `app.js`
- `manifest.json`

Après un premier chargement depuis HTTP local ou HTTPS, l’application peut fonctionner hors ligne. La stratégie réseau puis cache permet aussi de récupérer les mises à jour quand le réseau est disponible.

## Maintien d’écran

Le mode live tente d’utiliser l’API Screen Wake Lock quand elle est disponible. Si le navigateur ne la supporte pas, l’application continue normalement. Dans ce cas, gardez l’écran actif avec les réglages de votre téléphone.

## Limites

- Pas de GPS ni mesure automatique de distance.
- Les passages doivent être validés manuellement.
- Les données sont stockées dans le navigateur utilisé.
- Effacer les données du site supprime les courses et la session active.
- La précision du bilan dépend du moment où vous touchez `Point passé`.
